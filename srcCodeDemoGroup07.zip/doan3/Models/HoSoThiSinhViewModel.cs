﻿namespace doan3.Models
{
    public class HoSoThiSinhViewModel
    {
        public HoSoThiSinh HoSoThiSinh { get; set; }
        public int? KetquaId { get; set; }
    }
}
